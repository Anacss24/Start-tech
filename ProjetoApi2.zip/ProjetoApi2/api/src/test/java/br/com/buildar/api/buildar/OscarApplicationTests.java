package br.com.oscar.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OscarApplicationTests {

	@Test
	void contextLoads() {
	}

}
