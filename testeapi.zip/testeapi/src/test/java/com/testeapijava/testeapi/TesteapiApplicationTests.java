package com.testeapijava.testeapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TesteapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
